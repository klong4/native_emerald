#import <Cocoa/Cocoa.h>
#import <OpenEmuBase/OEGameCore.h>

OE_EXPORTED_CLASS
@interface mGBAGameCore : OEGameCore
@end
